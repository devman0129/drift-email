module.exports = {
  JWT_SECRET: 'secret',
  DEFAULT_PASSWORD: '12345678',
  TOKEN_EXPIRED_TIME: '7d',
};
